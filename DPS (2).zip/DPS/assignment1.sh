#!/bin/bash

# Define database credentials
DATABASE_NAME="postgres"
DATABASE_USER="postgres"
DATABASE_PASSWORD="postgres"  # Replace with the actual password for your setup

# Specify the full path to the psql executable (adjust the path as per your installation)
PSQL_EXEC="/c/Program Files/PostgreSQL/17/bin/psql.exe"

echo "Initiating Assignment 1 Process..."

# Step 1: Run Table Creation Script
start_time=$(date +%s)
echo "Creating database tables..."
PGPASSWORD="$DATABASE_PASSWORD" "$PSQL_EXEC" -U $DATABASE_USER -d $DATABASE_NAME -f create_tables.sql
end_time=$(date +%s)
echo "Table creation duration: $((end_time - start_time)) seconds"

# Step 2: Import Data into the Tables
start_time=$(date +%s)
echo "Importing data..."
PGPASSWORD="$DATABASE_PASSWORD" "$PSQL_EXEC" -U $DATABASE_USER -d $DATABASE_NAME -f load_data.sql
end_time=$(date +%s)
echo "Data import duration: $((end_time - start_time)) seconds"

# Step 3: Establish Relationships in the Database
start_time=$(date +%s)
echo "Setting up relationships between tables..."
PGPASSWORD="$DATABASE_PASSWORD" "$PSQL_EXEC" -U $DATABASE_USER -d $DATABASE_NAME -f create_relations.sql
end_time=$(date +%s)
echo "Relationship setup duration: $((end_time - start_time)) seconds"

# Step 4: Execute Queries on the Database
start_time=$(date +%s)
echo "Executing queries..."
PGPASSWORD="$DATABASE_PASSWORD" "$PSQL_EXEC" -U $DATABASE_USER -d $DATABASE_NAME -f queries.sql
end_time=$(date +%s)
echo "Query execution duration: $((end_time - start_time)) seconds"

echo "Assignment 1 Process Completed Successfully!"
