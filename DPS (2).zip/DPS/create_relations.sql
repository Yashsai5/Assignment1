-- Set up foreign key relationships

-- Associate submissions with authors based on the author's name
ALTER TABLE submissions
ADD CONSTRAINT fk_submissions_author
FOREIGN KEY (author) 
REFERENCES authors(name) 
ON DELETE CASCADE;

-- Associate comments with authors based on the author's name
ALTER TABLE comments
ADD CONSTRAINT fk_comments_author
FOREIGN KEY (author) 
REFERENCES authors(name) 
ON DELETE CASCADE;

-- Associate submissions with subreddits using the subreddit_id
ALTER TABLE submissions
ADD CONSTRAINT fk_submissions_subreddit
FOREIGN KEY (subreddit_id) 
REFERENCES subreddits(name) 
ON DELETE CASCADE;

-- Associate comments with subreddits using the subreddit_id
ALTER TABLE comments
ADD CONSTRAINT fk_comments_subreddit_id
FOREIGN KEY (subreddit_id) 
REFERENCES subreddits(name) 
ON DELETE CASCADE;

-- Associate comments with subreddits using the display_name
ALTER TABLE comments
ADD CONSTRAINT fk_comments_subreddit_display_name
FOREIGN KEY (subreddit) 
REFERENCES subreddits(display_name) 
ON DELETE CASCADE;
