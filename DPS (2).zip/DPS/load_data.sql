-- Import authors data from CSV file
\copy authors(id, retrieved_on, name, created_utc, link_karma, comment_karma, profile_img, profile_color, profile_over_18) 
FROM 'C:/DPS/authors.csv' 
WITH (FORMAT CSV, HEADER, ENCODING 'UTF-8');

-- Import subreddits data from CSV file
\copy subreddits(banner_background_image, created_utc, description, display_name, header_img, hide_ads, id, over_18, 
                 public_description, retrieved_utc, name, subreddit_type, subscribers, title, whitelist_status) 
FROM 'C:/DPS/subreddits.csv' 
WITH (FORMAT CSV, HEADER, ENCODING 'UTF-8');

-- Import submissions data from CSV file
\copy submissions(downs, url, id, edited, num_reports, created_utc, name, title, author, permalink, num_comments, 
                 likes, subreddit_id, ups) 
FROM 'C:/DPS/submissions.csv' 
WITH (FORMAT CSV, HEADER, ENCODING 'UTF-8');

-- Import comments data from CSV file
\copy comments(distinguished, downs, created_utc, controversiality, edited, gilded, author_flair_css_class, id, 
               author, retrieved_on, score_hidden, subreddit_id, score, name, author_flair_text, link_id, archived, 
               ups, parent_id, subreddit, body) 
FROM 'C:/DPS/comments.csv' 
WITH (FORMAT CSV, HEADER, ENCODING 'UTF-8');
